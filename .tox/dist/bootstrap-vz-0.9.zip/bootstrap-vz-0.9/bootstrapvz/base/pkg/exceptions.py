

class PackageError(Exception):
	"""Raised when an error occurrs while handling the packageslist
	"""
	pass


class SourceError(Exception):
	"""Raised when an error occurs while handling the sourceslist
	"""
	pass
