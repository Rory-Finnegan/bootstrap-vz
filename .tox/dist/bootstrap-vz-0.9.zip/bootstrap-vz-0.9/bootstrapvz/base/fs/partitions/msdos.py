from base import BasePartition


class MSDOSPartition(BasePartition):
	"""Represents an MS-DOS partition
	"""
	pass
